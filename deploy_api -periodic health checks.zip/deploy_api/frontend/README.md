# Deploy Dashboard Frontend

Svelte frontend. Builds directly to `../static/`.

## Development

```bash
npm install
npm run dev
# → http://localhost:5173 (API proxied to :8000)
```

## Production Build

```bash
npm run build
# → Outputs to ../static/
```
