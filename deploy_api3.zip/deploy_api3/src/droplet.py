"""
Droplet provisioning and management.
Uses typed entities.
"""

import asyncio
import json
from typing import Dict, Any, AsyncIterator

from ...shared_libs.backend.cloud import AsyncDOClient

from .stores import projects, services, deployments, droplets, containers, snapshots
from . import agent_client
from .naming import get_domain_name, get_host_port
from .utils import is_webservice, get_is_managed, DEPLOY_API_TAG
from .naming import create_droplet_name, create_vpc_name
from .sse_streaming import StreamContext, sse_complete, sse_log


async def _ensure_vpc(do_client, vpc_name: str, region: str) -> str:
    """Create VPC if not exists, return vpc_uuid.
    
    Reuses any existing VPC in the region to avoid IP range conflicts.
    """
    existing = await do_client.list_vpcs()
    
    # First, try to find VPC with exact name
    for vpc in existing:
        if vpc.name == vpc_name and vpc.region == region:
            return vpc.id
    
    # Otherwise, reuse any VPC in the same region (avoids IP range conflicts)
    for vpc in existing:
        if vpc.region == region:
            return vpc.id
    
    # No VPC in region - create new one
    vpc = await do_client.create_vpc(name=vpc_name, region=region, ip_range="10.10.0.0/16")
    return vpc.id


async def create_droplet(
    db, user_id: str, snapshot_id: str, region: str, size: str, 
    do_token: str, name: str = None
) -> Dict[str, Any]:
    """Create a new droplet in VPC."""    
    
    async with AsyncDOClient(api_token=do_token) as do_client:
        vpc_name = create_vpc_name(user_id, region)
        vpc_uuid = await _ensure_vpc(do_client, vpc_name, region)
        
        droplet_name = name or create_droplet_name()
        
        snap = await snapshots.get(db, snapshot_id)
        if not snap:
            return {'error': f'Snapshot {snapshot_id} not found'}
        
        # Create droplet - returns typed Droplet object
        result = await do_client.create_droplet(
            name=droplet_name, region=region, size=size,
            image=snap.do_snapshot_id, vpc_uuid=vpc_uuid,
            tags=[DEPLOY_API_TAG, f"user:{user_id}"],
        )
        
        do_droplet_id = result.id
        ip = result.ip
        private_ip = result.private_ip
        
        # If create_droplet didn't wait, poll for IP
        if not ip:
            for _ in range(30):
                await asyncio.sleep(2)
                info = await do_client.get_droplet(do_droplet_id)
                if info and info.ip:
                    ip = info.ip
                    private_ip = info.private_ip
                    break
        
        if not ip:
            return {'error': 'Timeout waiting for IP'}
        
        # Save to DB - returns typed Droplet entity
        droplet = await droplets.create(db, {
            'workspace_id': user_id, 
            'name': droplet_name,
            'do_droplet_id': do_droplet_id, 
            'region': region,
            'size': size, 
            'ip': ip, 
            'private_ip': private_ip,
            'vpc_uuid': vpc_uuid, 
            'snapshot_id': snapshot_id,
            'health_status': 'healthy',
        })
        
        # Return as dict for compatibility with deploy_service
        return {
            'id': droplet.id,
            'ip': droplet.ip,
            'private_ip': droplet.private_ip,
            'name': droplet.name,
        }


async def delete_droplet(
    db, user_id: str, droplet_id: str, do_token: str, cf_token: str
) -> AsyncIterator[str]:
    """Delete a droplet - always forceful."""
    stream = StreamContext()
    
    try:
        droplet = await droplets.get(db, droplet_id)
        if not droplet:
            raise Exception('Droplet not found')
        
        stream(f'deleting droplet {droplet.name} ({droplet.ip})...')
        yield sse_log(stream._logs[-1])
        
        # Get containers on this droplet
        droplet_containers = await containers.list_for_droplet(db, droplet_id)
        
        if droplet_containers:
            stream(f'{len(droplet_containers)} containers will be destroyed.')
            yield sse_log(stream._logs[-1])
            
            # Find affected deployments
            affected_deps = set(
                c.deployment_id for c in droplet_containers if c.deployment_id
            )
            
            for dep_id in affected_deps:
                dep = await deployments.get(db, dep_id)
                if not dep:
                    continue
                
                service = await services.get(db, dep.service_id)
                if not service or not is_webservice(service.service_type or ''):
                    continue
                
                project = await projects.get(db, service.project_id)
                if not project:
                    continue
                
                domain = get_domain_name(user_id, project.name, service.name, dep.env)
                
                # Parse droplet IDs
                dep_ids = dep.droplet_ids
                if isinstance(dep_ids, str):
                    dep_ids = json.loads(dep_ids)
                remaining_ids = [d for d in dep_ids if d != droplet_id]
                
                if not remaining_ids:
                    # No droplets remain - remove DNS
                    stream(f'  no droplets remain for {domain}, removing DNS...')
                    yield sse_log(stream._logs[-1])
                    from .dns import remove_domain
                    await remove_domain(cf_token, domain)
                    continue
                
                # Update nginx on remaining droplets
                remaining_infos = [await droplets.get(db, did) for did in remaining_ids]
                remaining_infos = [d for d in remaining_infos if d and d.ip]
                
                # Determine managed mode from first droplet's snapshot
                snapshot_id = remaining_infos[0].snapshot_id if remaining_infos else None
                is_managed = await get_is_managed(db, snapshot_id)
                
                remaining_agent_ips = [d.private_ip or d.ip if is_managed else d.ip for d in remaining_infos]
                remaining_private = [d.private_ip or d.ip for d in remaining_infos]
                remaining_public_ips = [d.ip for d in remaining_infos]  # For DNS
                host_port = get_host_port(
                    user_id, project.name, service.name, 
                    dep.env, dep.version, service.service_type
                )
                
                stream(f'  updating nginx on {len(remaining_ids)} droplets...')
                yield sse_log(stream._logs[-1])
                await asyncio.gather(
                    *[agent_client.configure_nginx(ip, remaining_private, host_port, domain, do_token) 
                      for ip in remaining_agent_ips],
                    return_exceptions=True
                )
                
                # Update DNS (uses public IPs)
                stream(f'  updating DNS for {domain}...')
                yield sse_log(stream._logs[-1])
                from .dns import setup_multi_server
                await setup_multi_server(cf_token, domain, remaining_public_ips)
            
            # Delete container records
            await containers.delete_by_droplet(db, droplet_id)
        
        # Delete from DigitalOcean
        stream('deleting from DigitalOcean...')
        yield sse_log(stream._logs[-1])
        async with AsyncDOClient(api_token=do_token) as client:
            await client.delete_droplet(droplet.do_droplet_id, force=True)
        
        # Delete from DB
        await droplets.delete(db, droplet_id)
        stream('droplet deleted.')
        yield sse_log(stream._logs[-1])
        yield sse_complete(True, droplet_id)
    
    except Exception as e:
        yield sse_log(f'Error: {e}', 'error')
        yield sse_complete(False, '', str(e))
