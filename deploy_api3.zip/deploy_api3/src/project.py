"""
projects operations
"""

import json
import asyncio
from typing import Optional, List, Dict, Any, AsyncIterator
from datetime import datetime, timezone

from shared_libs.backend.resilience import retry_with_backoff

from .stores import projects, services, deployments, droplets, containers
from . import agent_client
from .service import delete_service
from .naming import (
    get_domain_name, get_container_name, get_image_name,
    get_container_port, get_host_port
)
from .utils import now_iso, parse_env_variables, is_stateful, is_webservice
from .stateful import get_stateful_urls
from .locks import acquire_deploy_lock, release_deploy_lock
from .sse_streaming import StreamContext, sse_complete, sse_log



async def delete_project(db, user_id: str, project_id: str, do_token: str, cf_token: str) -> AsyncIterator[str]:
    """Delete project and all services."""
    stream = StreamContext()
    
    try:
        project = await projects.get(db, project_id)
        if not project:
            raise Exception('Project not found')
        
        stream(f'deleting project {project["name"]}...')
        yield sse_log(stream._logs[-1])
        
        project_services = await services.list_for_project(db, project_id)
        
        for svc in project_services:
            async for event in delete_service(db, user_id, svc['id'], env=None, do_token=do_token, cf_token=cf_token):
                yield event
        
        await projects.delete(db, project_id)
        stream('project deleted.')
        yield sse_log(stream._logs[-1])
        yield sse_complete(True, project_id)
    
    except Exception as e:
        yield sse_log(f'Error: {e}', 'error')
        yield sse_complete(False, '', str(e))
