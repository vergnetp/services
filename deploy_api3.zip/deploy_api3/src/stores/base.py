"""
Base store using schema-first entity framework.

Uses db.save_entity() and db.find_entities() with explicit schemas.
Schema defined in schemas.py with @entity decorators.

Serialization/deserialization handled by databases module:
- save_entity() auto-serializes lists/dicts to JSON
- find_entities(deserialize=True) auto-deserializes back
"""

import uuid
from typing import Dict, Any, List, Optional, TypeVar, Type, Generic
from datetime import datetime, timezone


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _generate_id() -> str:
    return str(uuid.uuid4())


T = TypeVar('T')


class BaseStore(Generic[T]):
    """
    Base store using schema-first entity framework.
    
    Schema is defined in schemas.py with @entity decorators.
    Auto-migration applies schema changes on startup.
    
    Usage:
        class ProjectStore(BaseStore[Project]):
            table_name = "projects"
            entity_class = Project
    """
    table_name: str = ""
    entity_class: Type[T] = None
    
    @classmethod
    def _to_entity(cls, row) -> Optional[T]:
        """Convert dict to typed entity."""
        if row is None:
            return None
        data = dict(row) if not isinstance(row, dict) else row
        if cls.entity_class and hasattr(cls.entity_class, 'from_dict'):
            return cls.entity_class.from_dict(data)
        return data
    
    @classmethod
    def _to_entities(cls, rows) -> List[T]:
        """Convert rows to typed entities."""
        return [cls._to_entity(r) for r in rows]
    
    @classmethod
    async def get(cls, db, id: str) -> Optional[T]:
        """Get entity by ID."""
        results = await db.find_entities(
            cls.table_name,
            where_clause="id = ?",
            params=(id,),
            limit=1,
            deserialize=True,
        )
        return cls._to_entity(results[0]) if results else None
    
    @classmethod
    async def create(cls, db, data: Dict[str, Any]) -> T:
        """Create new entity (schema managed by @entity decorators)."""
        data['id'] = data.get('id') or _generate_id()
        data['created_at'] = data.get('created_at') or _now_iso()
        data['updated_at'] = _now_iso()
        
        # save_entity handles serialization
        await db.save_entity(cls.table_name, data)
        
        return cls._to_entity(data)
    
    @classmethod
    async def update(cls, db, id: str, data: Dict[str, Any]) -> T:
        """Update entity (schema managed by @entity decorators)."""
        # Get existing
        existing = await cls.get(db, id)
        if not existing:
            return None
        
        # Merge with existing
        if hasattr(existing, '__dict__'):
            merged = {**existing.__dict__, **data}
        else:
            merged = {**existing, **data}
        
        merged['updated_at'] = _now_iso()
        
        # save_entity handles serialization
        await db.save_entity(cls.table_name, merged)
        
        return await cls.get(db, id)
    
    @classmethod
    async def delete(cls, db, id: str) -> bool:
        """Hard delete entity."""
        await db.execute(f"DELETE FROM {cls.table_name} WHERE id = ?", (id,))
        return True
    
    @classmethod
    async def soft_delete(cls, db, id: str) -> bool:
        """Soft delete (set deleted_at)."""
        return await cls.update(db, id, {'deleted_at': _now_iso()}) is not None
    
    @classmethod
    async def find(cls, db, where_clause: str = None, params: tuple = None, 
                   limit: int = None, order_by: str = None) -> List[T]:
        """Find entities with optional filtering."""
        results = await db.find_entities(
            cls.table_name,
            where_clause=where_clause,
            params=params,
            limit=limit,
            order_by=order_by,
            deserialize=True,
        )
        return cls._to_entities(results)
