"""Droplet and snapshot provisioning."""

import asyncio
import json
from typing import Dict, Any, List
import asyncssh

from shared_libs.backend.cloud import AsyncDOClient

from .stores import projects, services, deployments, droplets, containers, snapshots
from . import agent_client
from .naming import (
   get_snapshot_base_name
)
from .utils import  is_webservice
from .naming import create_droplet_name, create_vpc_name
from .sse_streaming import StreamContext, sse_complete, sse_log


# =============================================================================
# Common Docker Images for Base Snapshot
# =============================================================================

BASE_IMAGES = {
        'redis:7-alpine': 6379,
        'postgres:16-alpine': 5432,
        'mongo:7': 27017,
        'opensearchproject/opensearch:2': 9200,
        'mysql:8': 3306,
    }

AGENT_VERSION = '1.0.0'


# =============================================================================
# Snapshot Creation
# =============================================================================

async def create_base_snapshot(
    db, user_id: str, region: str, do_token: str,
    name: str = None, images: List[str] = None, size: str = 's-1vcpu-1gb'
) -> Dict[str, Any]:
    """
    Create base snapshot with Docker, nginx, node agent, and pre-pulled images.
    
    1. Create temp droplet from Ubuntu
    2. Install Docker, nginx, node agent
    3. Pull common images
    4. Snapshot
    5. Delete temp droplet
    """
    
    images = images or await list_base_images()
    name = name or get_snapshot_base_name()
    
    async with AsyncDOClient(api_token=do_token) as client:
        # 1. Create temp droplet from Ubuntu
        temp_name = f'temp-snapshot-{region}'
        result = await client.create_droplet(
            name=temp_name, region=region, size=size,
            image='ubuntu-24-04-x64',  # Base Ubuntu
            tags=[f'user:{user_id}', 'temp-snapshot'],
        )
        do_droplet_id = result['id']
        
        # Wait for IP
        ip = None
        for _ in range(30):
            await asyncio.sleep(2)
            info = await client.get_droplet(do_droplet_id)
            for net in info.get('networks', {}).get('v4', []):
                if net.get('type') == 'public':
                    ip = net.get('ip_address')
                    break
            if ip:
                break
        
        if not ip:
            await client.delete_droplet(do_droplet_id)
            return {'error': 'Timeout waiting for IP'}
        
        # Wait for SSH ready
        await asyncio.sleep(30)
        
        # 2. Install Docker, nginx, node agent via SSH
        setup_script = _get_setup_script(do_token, images)        

        async with asyncssh.connect(ip, username='root', known_hosts=None) as conn:
            # Run setup
            result = await conn.run(setup_script, check=True)
            if result.exit_status != 0:
                await client.delete_droplet(do_droplet_id)
                return {'error': f'Setup failed: {result.stderr}'}
        
        # 3. Power off before snapshot
        await client.power_off_droplet(do_droplet_id)
        await asyncio.sleep(10)
        
        # 4. Create snapshot
        snapshot = await client.create_snapshot(do_droplet_id, name=name)
        do_snapshot_id = snapshot['id']
        
        # 5. Delete temp droplet
        await client.delete_droplet(do_droplet_id)
        
        # 6. Save to DB
        snap = await snapshots.create(db, {
            'workspace_id': user_id,
            'do_snapshot_id': str(do_snapshot_id),
            'name': name,
            'region': region,
            'size_gigabytes': snapshot.get('size_gigabytes'),
            'agent_version': AGENT_VERSION,
            'is_base': True,
        })

        #todo: firewall all ports but 9999 and 443, and allow for ADMIN_IPS for port 22
        
        return snap


def _get_setup_script(do_token: str, images: List[str]) -> str:
    """Generate setup script for base snapshot."""
    
    # Read agent code
    import os
    agent_path = os.path.join(os.path.dirname(__file__), '..', 'node_agent', 'agent.py')
    with open(agent_path) as f:
        agent_code = f.read()
    
    # Generate API key
    import hmac, hashlib
    api_key = hmac.new(do_token.encode(), b"node-agent:", hashlib.sha256).hexdigest()
    
    # Image pull commands
    pull_cmds = '\n'.join(f'docker pull {img}' for img in images)
    
    return f'''#!/bin/bash
set -e

# Update system
apt-get update && apt-get upgrade -y

# Install Docker
curl -fsSL https://get.docker.com | sh
systemctl enable docker
systemctl start docker

# Install nginx
apt-get install -y nginx
systemctl enable nginx

# Create SSL placeholder (user should replace)
mkdir -p /etc/nginx/ssl
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
    -keyout /etc/nginx/certificate.key \
    -out /etc/nginx/certificate.pem \
    -subj "/CN=localhost"

# Install Python deps for agent
apt-get install -y python3-pip
pip3 install flask --break-system-packages

# Create agent directory
mkdir -p /opt/node_agent

# Write agent code
cat > /opt/node_agent/agent.py << 'AGENT_EOF'
{agent_code}
AGENT_EOF

# Create systemd service for agent
cat > /etc/systemd/system/node-agent.service << 'SERVICE_EOF'
[Unit]
Description=Node Agent
After=network.target docker.service

[Service]
Type=simple
Environment="NODE_AGENT_API_KEY={api_key}"
ExecStart=/usr/bin/python3 /opt/node_agent/agent.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SERVICE_EOF

systemctl daemon-reload
systemctl enable node-agent

# Create /data directory for volumes
mkdir -p /data

# Pull common Docker images
{pull_cmds}

# Clean up
apt-get clean
rm -rf /var/lib/apt/lists/*

echo "Setup complete"
'''


# =============================================================================
# Snapshot Deletion
# =============================================================================

async def delete_snapshot(db, snapshot_id: str, do_token: str) -> Dict[str, Any]:
    """Delete snapshot from DO and DB."""
   
    snap = await snapshots.get(db, snapshot_id)
    if not snap:
        return {'error': 'Snapshot not found'}
    
    async with AsyncDOClient(api_token=do_token) as client:
        try:
            await client.delete_snapshot(snap['do_snapshot_id'])
        except Exception as e:
            # May already be deleted on DO side
            pass
    
    await snapshots.delete(db, snapshot_id)
    
    return {'status': 'deleted', 'name': snap.get('name')}


# =============================================================================
# List Available Images
# =============================================================================

async def list_base_images() -> List[str]:
    """Return list of available base images."""
    return list(BASE_IMAGES.keys())

