"""
Health monitoring & healing.
Uses typed entities.
"""

import logging
from typing import Dict, Any

from shared_libs.backend.cloud import AsyncDOClient

from . import agent_client
from .stores import droplets, containers
from .utils import now_iso

logger = logging.getLogger(__name__)

MAX_CONTAINER_RESTARTS = 3
MAX_DROPLET_REBOOTS = 2


# =============================================================================
# Main Health Check Loop
# =============================================================================

async def check_health_all(db, do_token: str):
    """
    Main health check loop. Called by background worker.
    Checks ALL droplets (healthy, unreachable, problematic).
    """
    all_droplets = await droplets.list_active(db)
    
    for droplet in all_droplets:
        try:
            await check_droplet_health(db, droplet, do_token)
        except Exception as e:
            logger.error(f"Error checking droplet {droplet.name}: {e}")


async def check_droplet_health(db, droplet, do_token: str):
    """
    Check droplet reachability and all its containers.
    Triggers healing if needed.
    """
    if not droplet.ip:
        return
    
    # Get the correct IP for agent calls (VPC IP in managed mode)
    ip = await agent_client.get_agent_ip(db, droplet)
    
    # 1. Check if agent is reachable
    try:
        resp = await agent_client.ping(ip, do_token)
        agent_ok = resp.get('status') == 'ok'
    except Exception:
        agent_ok = False
    
    if not agent_ok:
        await handle_droplet_unreachable(db, droplet, do_token)
        return
    
    # 2. Agent OK - reset ALL failure state
    if (droplet.failure_count or 0) > 0 or droplet.health_status != 'healthy':
        await droplets.update(db, droplet.id, {
            'health_status': 'healthy',
            'failure_count': 0,
            'problematic_reason': None,
            'flagged_at': None,
            'last_checked': now_iso(),
        })
    
    # 3. Check all containers on this droplet
    droplet_containers = await containers.list_for_droplet(db, droplet.id)
    
    for container in droplet_containers:
        await check_container_health(db, droplet, container, do_token)


async def check_container_health(db, droplet, container, do_token: str):
    """
    Check single container health via node agent.
    Agent returns: {'status': 'healthy|unhealthy|degraded', 'reason': '...'}
    """
    ip = await agent_client.get_agent_ip(db, droplet)
    container_name = container.container_name
    
    try:
        status = await agent_client.container_status(ip, container_name, do_token)
    except Exception:
        status = None
    
    if not status or status.get('error') == 'not_found':
        await mark_container_unhealthy(db, container, 'not_found')
        return
    
    state = status.get('state')
    health = status.get('health_status', 'none')
    
    if state != 'running':
        await mark_container_unhealthy(db, container, f'state:{state}')
        await heal_container(db, droplet, container, do_token)
        return
    
    if health == 'unhealthy':
        await mark_container_unhealthy(db, container, 'health_check_failed')
        await heal_container(db, droplet, container, do_token)
        return
    
    # Healthy - reset failure count
    if (container.failure_count or 0) > 0 or container.health_status != 'healthy':
        await containers.update(db, container.id, {
            'health_status': 'healthy',
            'failure_count': 0,
            'last_healthy_at': now_iso(),
            'last_checked': now_iso(),
        })


async def mark_container_unhealthy(db, container, reason: str):
    """Record container failure."""
    await containers.update(db, container.id, {
        'health_status': 'unhealthy',
        'failure_count': (container.failure_count or 0) + 1,
        'last_failure_at': now_iso(),
        'last_failure_reason': reason,
        'last_checked': now_iso(),
    })
    logger.warning(f"Container {container.container_name} unhealthy: {reason}")


# =============================================================================
# Healing
# =============================================================================

async def heal_container(db, droplet, container, do_token: str):
    """
    Attempt to restart unhealthy container.
    If too many failures, flag droplet as problematic.
    """
    failure_count = container.failure_count or 0
    
    if failure_count >= MAX_CONTAINER_RESTARTS:
        logger.warning(
            f"Container {container.container_name} failed {failure_count} times, "
            f"flagging droplet"
        )
        await flag_droplet_problematic(
            db, droplet, f"container {container.container_name} keeps failing"
        )
        return
    
    ip = await agent_client.get_agent_ip(db, droplet)
    logger.info(f"Restarting container {container.container_name} on {ip}")
    
    try:
        await agent_client.restart_container(ip, container.container_name, do_token)
        await containers.update(db, container.id, {'last_restart_at': now_iso()})
    except Exception as e:
        logger.error(f"Failed to restart container: {e}")


async def handle_droplet_unreachable(db, droplet, do_token: str):
    """
    Droplet agent not responding. Increment failure count, maybe reboot.
    """
    new_count = (droplet.failure_count or 0) + 1
    
    await droplets.update(db, droplet.id, {
        'health_status': 'unreachable',
        'failure_count': new_count,
        'last_failure_at': now_iso(),
    })
    
    if new_count > MAX_DROPLET_REBOOTS:
        await flag_droplet_problematic(db, droplet, 'unreachable after reboots')
        return
    
    logger.warning(f"Droplet {droplet.name} unreachable (attempt {new_count}), rebooting...")
    await heal_droplet(db, droplet, do_token)


async def heal_droplet(db, droplet, do_token: str):
    """Reboot droplet via DigitalOcean API."""
    try:
        async with AsyncDOClient(api_token=do_token) as client:
            await client.reboot_droplet(droplet.do_droplet_id)
        
        await droplets.update(db, droplet.id, {'last_reboot_at': now_iso()})
        logger.info(f"Reboot initiated for {droplet.name}")
    except Exception as e:
        logger.error(f"Failed to reboot droplet: {e}")
        await flag_droplet_problematic(db, droplet, f'reboot failed: {e}')


async def flag_droplet_problematic(db, droplet, reason: str):
    """Mark droplet as needing manual intervention."""
    await droplets.update(db, droplet.id, {
        'health_status': 'problematic',
        'problematic_reason': reason,
        'flagged_at': now_iso(),
    })
    logger.error(f"DROPLET FLAGGED: {droplet.name} - {reason}")
    # TODO: send alert (email, slack, etc.)


# =============================================================================
# Dashboard Functions
# =============================================================================

async def get_health_overview(db) -> Dict[str, Any]:
    """Get health overview for dashboard."""
    all_droplets = await droplets.list_active(db)
    all_containers = await containers.list_active(db)
    
    droplet_stats = {'healthy': 0, 'unhealthy': 0, 'unreachable': 0, 'problematic': 0}
    container_stats = {'healthy': 0, 'unhealthy': 0, 'degraded': 0, 'unknown': 0}
    
    for d in all_droplets:
        status = d.health_status or 'unknown'
        if status in droplet_stats:
            droplet_stats[status] += 1
    
    for c in all_containers:
        status = c.health_status or 'unknown'
        if status in container_stats:
            container_stats[status] += 1
        else:
            container_stats['unknown'] += 1
    
    return {
        'droplets': droplet_stats,
        'containers': container_stats,
        'problematic_droplets': [d for d in all_droplets if d.health_status == 'problematic'],
        'unhealthy_containers': [c for c in all_containers if c.health_status == 'unhealthy'],
    }


async def clear_problematic_flag(db, droplet_id: str) -> Dict[str, Any]:
    """Clear problematic flag after manual intervention."""
    droplet = await droplets.get(db, droplet_id)
    if not droplet:
        return {'error': 'Droplet not found'}
    
    await droplets.update(db, droplet_id, {
        'health_status': 'healthy',
        'failure_count': 0,
        'problematic_reason': None,
        'flagged_at': None,
    })
    
    return {'status': 'cleared', 'droplet': droplet.name}
