"""
Auto-generated routes from manifest.yaml
DO NOT EDIT - changes will be overwritten on regenerate

These provide basic CRUD scaffolding. For custom routes, use src/routes/.
"""

from fastapi import APIRouter

# Note: Entity-specific routes are available but not auto-mounted
# The deploy_api uses custom routes in src/routes/ instead
# These are here for reference/future use

__all__ = []
